package com.mipk.struts2;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.apache.struts2.interceptor.SessionAware;

public class HelloWorldAction implements SessionAware{
	
	private static final Logger logger = LogManager.getLogger(HelloWorldAction.class);
	private String name;

	   public String execute() throws Exception {
	      return "success";
	   }
	   
	   public String getName() {
	      return name;
	   }

	   public void setName(String name) {
	      this.name = name;
	   }
	   
	   public boolean acceptableParameterName(String parameterName) {
		    boolean allowedParameterName = true ;

		    if ( parameterName.contains("session")  || parameterName.contains("request") ) {
		        allowedParameterName = false ;
		    } 

		    return allowedParameterName;
		}
	   
	   private Map<String, Object> userSession ;

	   public void setSession(Map<String, Object> session) {
	      userSession = session ;
	   }
	   
	   private String HELLO_COUNT="HELLO_COUNT"; 
	   
	   private void increaseHelloCount() {
		    Integer helloCount = (Integer) userSession.get(HELLO_COUNT);

		    if (helloCount == null ) {
		        helloCount = 1;
		    } else {
		        helloCount++;
		    }
		    
		    logger.error("-------- increaseHelloCount-----helloCount------ " + helloCount);

		    userSession.put(HELLO_COUNT, helloCount);
		}

}
