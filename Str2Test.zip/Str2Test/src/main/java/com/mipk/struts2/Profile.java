package com.mipk.struts2;

import javax.servlet.http.HttpSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.apache.struts2.ServletActionContext;

public class Profile{
	
	private static final Logger logger = LogManager.getLogger(Profile.class);

	public String execute(){
		HttpSession session=ServletActionContext.getRequest().getSession(false);
		
		logger.error("-------- Profile1.execute 1------------ ");
		
		if(session==null || session.getAttribute("login")==null){
			return "login";
		}
		else{
			logger.error("-------- Profile1.execute 2 success------------> " + session.getAttribute("login"));
			return "success";
		}
	}
}
