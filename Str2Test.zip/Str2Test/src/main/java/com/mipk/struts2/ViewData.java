package com.mipk.struts2;

public class ViewData {
	
	private String name = "NAME";
	private String data1 = "DATA1";
	private String data2 = "DATA2";

	   public String execute() throws Exception {
	      return "success";
	   }
	   
	   public String getName() {
	      return name;
	   }

	   public void setName(String name) {
	      this.name = name;
	   }
	   
	   public String getData1() {
		      return data1;
		   }

	   public void setDta1(String dt) {
		   	this.data1 = dt;
	   }
	   public String getData2() {
		   return data2;
	   }

	   public void setDta2(String dt) {
		   this.data2 = dt;
	   }

}
