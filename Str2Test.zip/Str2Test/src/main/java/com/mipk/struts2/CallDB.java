package com.mipk.struts2;

import com.opensymphony.xwork2.ActionSupport;

//import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CallDB extends ActionSupport {
    
    private static final long serialVersionUID = 1L;
    
    private static final Logger logger = LogManager.getLogger(CallDB.class);
    
    private List<Product> products;
    
    public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}
    
    public String execute() throws Exception {
    	try {
    		this.products = TestDB.getProducts();
        	logger.error("-------- CallDB products SIZE ------------ "+ this.products.size());
        	
        	
        	//this.products = new ArrayList<Product>();
    		//this.products.add(new Product("p01", "name 1", "thumb1.gif", 2, 4));
    		//this.products.add(new Product("p02", "name 2", "thumb2.gif", 6, 3));
    	
    		if (this.products.size()==0) {
    			String s = "Error products.size 0";
        		logger.error(s);
        		this.setMsgErr(s);
        		return ERROR;
    			
    		}
    		
    		return SUCCESS;
    		
    	}
    	catch (Exception err){
    		String s = err.getMessage();
    		logger.error(s);
    		this.setMsgErr(s);
    		return ERROR;
    		
    	}
		
	}
    //setter and getter error msg
    //and put error msg in errorDb.jsp
    private String MsgErr;
    public void setMsgErr(String msg) {
    	this.MsgErr = msg;
    }
    public String getMsgErr() {
    	return this.MsgErr;
    }
    

}
