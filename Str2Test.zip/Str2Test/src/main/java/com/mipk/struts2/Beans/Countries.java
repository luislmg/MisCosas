package com.mipk.struts2.Beans;

public class Countries {
	private String name;
	private String code;
	
	public Countries (String name, String code) {
	    super();
	    this.name = name;
	    this.code = code;
	   
	  }
	
	
	
	public String getName() {
	    return this.name;
	  }
	
	public String getCode() {
	    return this.code;
	  }
}
