package com.mipk.struts2.DbOutils;

import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;



public class DbConnection {
	
	private static final Logger logger = LogManager.getLogger(DbConnection.class);
	
	/*
     * Call initial context
     * and retrieve Datasoruce
     * get the sql connection from connection poll
     */
    public static java.sql.Connection getCon () throws Exception {
		
    	
		
		Connection con = null;
		
		//int ress = 0;
		try {
			//System.out.println ("Entro con2");
			InitialContext ctx = new InitialContext();
			Context env = (Context) ctx.lookup("java:comp/env");
			logger.debug("InitialContext OK");
			//System.out.println ("Entro con3");
			// nombre del recurso en el context.xml
			DataSource ds = (DataSource) env.lookup("jdbc/MariaDB");
			logger.debug("DataSource OK");
			//System.out.println ("Entro con4");

			
			con = ds.getConnection();
			logger.debug("getConnection OK");
			
			return con;
			
			
		} catch (Exception e) {
			logger.error(e.getMessage());
        	throw new Exception(e.getMessage());
			
		}
		
		

	}

}
