package com.mipk.struts2;



import java.io.File;
import java.util.ArrayList;

import java.util.List;
import java.util.Map;




import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.apache.struts2.ServletActionContext;

import org.apache.struts2.interceptor.SessionAware;


import com.opensymphony.xwork2.ActionSupport;

/**
 *
 * 
 */
public class TestSelect extends ActionSupport implements SessionAware{
	private static final long serialVersionUID = 1L;
	private static final Logger logger = LogManager.getLogger(TestSelect.class);
	//data members
	private List<String> subjectList;
	private String selectedSubject;
	private String noFiles = "!!!! NO FILES !!!!!";
	
	private Map<String, Object> sessionMap;
	
	@Override
	public void setSession(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}
	
	//business logic
	public String execute(){
		
		if (selectedSubject == noFiles) {
			logger.error("-- TestSelect.execute.selectedSubject ---1--> "  + selectedSubject);
			setMsgErr(noFiles);
			return ERROR;	
		}
		else {
			sessionMap.put("DownloadFile", selectedSubject);

			logger.error("-- TestSelect.execute.selectedSubject ---1--> "  + selectedSubject);

			return SUCCESS;	
			
		}

	}
	
	//setter and getter error msg
    //and put error msg in errorDb.jsp
    private String MsgErr;
    public void setMsgErr(String msg) {
    	this.MsgErr = msg;
    }
    public String getMsgErr() {
    	return this.MsgErr;
    }

	
	//getter setters
	public List<String> getSubjectList() {
		return subjectList;
	}

	public void setSubjectList(List<String> subjectList) {
		this.subjectList = subjectList;
	}

	public String getSelectedSubject() {
		return selectedSubject;
	}

	public void setSelectedSubject(String selectedSubject) {
		this.selectedSubject = selectedSubject;
	}
	
	public String getDefaultSubject() {
		return "Java";
	}
	
	private String localDirectory = null;
	 public void setlocalDirectory(String s) {
		  this.localDirectory = s;
	  }
	  public String getlocalDirectory() {
	    	return this.localDirectory;
	  }
		 
	public String initializeList(){
				
		subjectList = new ArrayList<String>();
				
	 	String filePath = ServletActionContext.getServletContext().getRealPath("/").concat("UploadFiles");  
	 	setlocalDirectory(filePath);
	 	logger.error("-- TestSelect.initializeList.filePath ---1--> "  + filePath);
	 	
	 	

	 	File[] files = new File(filePath).listFiles();
	 	//If this pathname does not denote a directory, then listFiles() returns null.
	 	if (files != null){
	 		for (File file : files) {
		 	    if (file.isFile()) {
		 			String s = (String)file.getName();
		 			subjectList.add(s);
		 			logger.error("-- TestSelect.initializeList -2---> "  + s);

		 	    }
		 	}
	 		
	 	}
	 	else {
	 		subjectList.add(noFiles);
	 	}
	 	

		return NONE;
	}

	

	
			
}

