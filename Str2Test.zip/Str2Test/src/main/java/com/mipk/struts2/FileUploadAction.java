package com.mipk.struts2;

import java.io.*;
import java.util.*;
import java.util.stream.*;
import org.apache.commons.io.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ValidationAware;

import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.SessionAware;
import java.util.Map;
 

public class FileUploadAction extends ActionSupport implements ValidationAware,  SessionAware {
	
private static final long serialVersionUID = 1L;
    
     private static final Logger logger = LogManager.getLogger(FileUploadAction.class);

	  private File uploadedFile;
	  private String uploadedFileName;
	  private String localDirectory = null;
	  
	  private Map<String, Object> sessionMap;
	  
	  private String userName;
	  private String password;
		
	 
	  
	  public void setUploadedFile(File file) {
	    uploadedFile = file;
	  }

	  public void setUploadedFileFileName(String name) {
	    uploadedFileName = name;
	  }
	  public void setlocalDirectory(String s) {
		  this.localDirectory = s;
	  }
	  public String getlocalDirectory() {
	    	return this.localDirectory;
	    }
	  
	 
	  
	  public void setSession(Map<String, Object> sessionMap) {
			this.sessionMap = sessionMap;
		}
		
		public void setUserName(String userName) {
			this.userName = userName;
		}
		
		public void setPassword(String password) {
			this.password = password;
		}
	
	  public String execute() throws Exception {
		 try { 
			 
			 boolean Is_authenticated = false;
			 String loggedUserName = null;
			 if (sessionMap.containsKey("userName")) {
					loggedUserName = (String) sessionMap.get("userName");
					Is_authenticated = true;
			 }
			//only authenticated users
			 if (Is_authenticated) {
				 logger.error("-- AuthenticationAction.login1 ---loggedUserName-->" + loggedUserName);
					//this value is in myapp.properties
				 	String UploadFiles = getText("UploadFiles");
				 	String filePath = ServletActionContext.getServletContext().getRealPath("/").concat(UploadFiles);  
				 	setlocalDirectory(filePath);
				 	
					logger.error("FileUploadAction.execute filePathh:" + filePath);
				 	logger.error("FileUploadAction.execute length:" + uploadedFile.length());
			        //System.out.println("File Location:" + filePath);//see the server console for actual location  
			        File fileToCreate = new File(filePath,loggedUserName+"_123_"+uploadedFileName);  
			        FileUtils.copyFile(uploadedFile, fileToCreate);//copying source file to new file  
				 
			        /*
				 	String savePath = localDirectory + "/" + uploadedFileName;
				 	logger.error("FileUploadAction.execute 1.1"+ savePath);
				 
				    File localFile = new File(localDirectory, uploadedFileName);
				    logger.error("FileUploadAction.execute length:" + uploadedFile.length());
				    
				    FileUtils.copyFile(uploadedFile, localFile);
				    logger.error("FileUploadAction.execute 2");
				    	*/
			        return SUCCESS;
				 
			 }
			 else {
				 return LOGIN;
			    	
			 }
			 
		 }
		 catch (Exception err){
			 
			 	String s = err.toString();
			 	System.out.println(s);
	    		logger.error(s);
	    		this.setMsgErr(s);
	    		return ERROR;
			 
		 }
		
	  }

	  /* Used to obtain a file listing for JSP display. */
	  public Set<String> getFileList() {
	    return Stream.of(new File(getlocalDirectory()).listFiles())
	      .filter(file -> !file.isDirectory())
	      .map(File::getName)
	      .collect(Collectors.toSet());
	  }
	  
	//setter and getter error msg
	    //and put error msg in errorDb.jsp
	    private String MsgErr;
	    public void setMsgErr(String msg) {
	    	this.MsgErr = msg;
	    }
	    public String getMsgErr() {
	    	return this.MsgErr;
	    }

	

	}


