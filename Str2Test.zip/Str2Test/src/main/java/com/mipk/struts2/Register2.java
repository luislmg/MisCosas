package com.mipk.struts2;

import com.opensymphony.xwork2.ActionSupport;
//import com.mipk.struts2.Person;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Register2 extends ActionSupport {
  
  private static final long serialVersionUID = 1L;
  
  private com.mipk.struts2.Person personBean;

//create the logger for log4j2
	private static final Logger logger = LogManager.getLogger(Register2.class);

  public String execute() throws Exception {
      //call Service class to store personBean's state in database
  	logger.debug("Register2 execute OK");
      return SUCCESS;
  }
  
  
  public Person getPersonBean() {
      return personBean;
  }
  
  public void setPersonBean(Person person) {
      personBean = person;
  }
  
//Method to validate the user input
  public void validate(){
      if (personBean.getFirstName().length() == 0) {
          addFieldError("personBean.firstName", "First name is required.");
      }

      if (personBean.getEmail().length() == 0) {
          addFieldError("personBean.email", "Email is required.");
      }

      if (personBean.getAge() < 18) {
          addFieldError("personBean.age", "Age is required and must be 18 or older");
      }
      logger.error("-------- ALL OK Register2 validate- AHORA22----------- ");
  }
}
