package com.mipk.struts2;

import java.text.DateFormat;
import java.util.Date;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


/*
 * this Interceptor don't work
 * 
 */
public class InterceptorSaludo implements Interceptor
{
	private static final long serialVersionUID = 1L;
	private static final Logger logger = LogManager.getLogger(InterceptorSaludo.class);
    
    public void destroy()
    {
    }

    
    public void init()
    {
		System.out.println("Hola desarrollador en el INIT");
		logger.error("InterceptorSaludo INIT:" );

    }

    /*
    public String intercept(ActionInvocation actionInvocation) throws Exception
    {
    	System.out.println("Hola desarrollador");
    }
*/

	@Override
	public String intercept(ActionInvocation invocation) throws Exception  {
		// TODO Auto-generated method stub
		logger.error("Iintercept:" );
		
		
		
		
		String actionName = (String)ActionContext.getContext().get(ActionContext.ACTION_NAME);
		String tiempoActual = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM).format(new Date());
		System.out.println("Hola desarrollador" + actionName + "/tiempo:/" + tiempoActual);
		logger.error("Iintercept:" + "Hola desarrollador" + actionName + "/tiempo:/" + tiempoActual);
		try {
			String resultado = invocation.invoke();
			logger.error("Iintercept: resultado:" + resultado);
			return resultado;
		}
		catch (Exception ex) {
			logger.error("Iintercept:" + ex.toString() );
			
		}
		return "ALGO PASO";
		
	}    
}
