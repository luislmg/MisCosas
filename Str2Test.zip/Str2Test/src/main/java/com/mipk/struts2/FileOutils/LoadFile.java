package com.mipk.struts2.FileOutils;

import org.apache.struts2.ServletActionContext;



import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.mipk.struts2.Product;
import com.mipk.struts2.Beans.Countries;

public class LoadFile {
	
	private static final Logger logger = LogManager.getLogger(LoadFile.class);
	
	 
	private static final char DEFAULT_SEPARATOR = ';';
	private static final char DOUBLE_QUOTES = '"';
    private static final char DEFAULT_QUOTE_CHAR = DOUBLE_QUOTES;
    private static final String NEW_LINE = "\n";

    private boolean isMultiLine = false;
    private String pendingField = "";
    private String[] pendingFieldLine = new String[]{};
    
	String localDirectory = null;
	
	public void setlocalDirectory(String s) {
		  this.localDirectory = s;
	  }
	  public String getlocalDirectory() {
	    	return this.localDirectory;
	    }
	
	  public static Integer IsNumber (String str) {
			try{
	            int number = Integer.parseInt(str);
	            return number;
	        }
	        catch (NumberFormatException ex){
	        	return 0;
	        }
		}
	  
	 
	  
	  public Hashtable<Integer, Object> readCSV3 () {
	    	
			String filePath = ServletActionContext.getServletContext().getRealPath("/").concat("Resource").concat("/countries.csv");  

			logger.error("LoadFile readCSV3 1" + filePath);
			 	String FileToRead = filePath;
			 	
			 	Path pathToFile = Paths.get(FileToRead );
			 	
			 	List<String> itemsToAdd = new ArrayList<String>();
			 	//List<Integer> Salary = new ArrayList<Integer>();
			 	String splitSep = ";";
			 	
			 	Hashtable<Integer, Object> milista1=new Hashtable<Integer, Object>();
			 	
			 	if (pathToFile.toFile().isFile()) {
			 	
			 		try (BufferedReader br = Files.newBufferedReader(pathToFile)) {
			    		String line = br.readLine();
			    		int count = 0;
			    		// Create a Hashtable to put beans
			    		Hashtable<Integer, Object> milista=new Hashtable<Integer, Object>();
			    		 
			    		while (line != null) {
			    			String[] attributes = line.split(splitSep);
			    			//int len = attributes.length;
			    			
			    			line = br.readLine();
			    			//Skip first line with titles
			    			if (count > 0) {
			    				//add Key  to ArrayList
				    			itemsToAdd.add(attributes[3]);
				    			//Salary.add (IsNumber(attributes[2]));
				    			//String date, String prod_class, int salary
				    			Countries nn = new Countries (attributes[0],attributes[3]);
				    			System.out.println("Country Name:" + attributes[0] +"/CountryCode:"+attributes[3]);
			    				//put the beans into the hashtable
				    			milista.put(count,nn);
				    			
			    			}
			    			count++;
			    			
			    		}
			    		logger.error("LoadFile readCSV3 2" + filePath);
			    		return milista;
			    		
			    		
			    	} 
			    	catch (IOException ioe) {
			    		System.out.println("------");
			    		logger.error("Error File");
				    	System.out.println("Error File");
			    	}
			 	}
			 	else
			 	{
			 		logger.error("File Not found");
			    	System.out.println("File Not found");
			 	}
			 	logger.error("LoadFile readCSV3 3 MALLL" + filePath);
			 	return milista1;
	    	}
	 

	  
	  
	  
	public void load () throws Exception {
		String filePath = ServletActionContext.getServletContext().getRealPath("/").concat("Resource").concat("countries.csv");  
	 	
	 	//setlocalDirectory(filePath);
	 	
		logger.error("LoadFile 1" + filePath);
		
	 	//logger.error("FileUploadAction.execute length:" + uploadedFile.length());
		
		List<List<String>> records = new ArrayList<>();
		try (Scanner scanner = new Scanner(new File(filePath));) {
		    while (scanner.hasNextLine()) {
		        records.add(getRecordFromLine(scanner.nextLine()));
		    }
		    logger.error("LoadFile 2" + filePath);
		}
		catch (Exception ex) {
			logger.error("LoadFile" + ex.toString());
			
			
		}

		
	}
	
	
	private String COMMA_DELIMITER = ";";
	
	
	
	private List<String> getRecordFromLine(String line) {
	    List<String> values = new ArrayList<String>();
	    try (Scanner rowScanner = new Scanner(line)) {
	        rowScanner.useDelimiter(COMMA_DELIMITER);
	        while (rowScanner.hasNext()) {
	            values.add(rowScanner.next());
	        }
	    }
	    return values;
	}
	
	/*
	
	public List<String[]> readFile(File csvFile, int skipLine)
	        throws Exception {

	        List<String[]> result = new ArrayList<>();
	        int indexLine = 1;

	        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {

	            String line;
	            while ((line = br.readLine()) != null) {

	                if (indexLine++ <= skipLine) {
	                    continue;
	                }

	                String[] csvLineInArray = parseLine(line);

	                if (isMultiLine) {
	                    pendingFieldLine = joinArrays(pendingFieldLine, csvLineInArray);
	                } else {

	                    if (pendingFieldLine != null && pendingFieldLine.length > 0) {
	                        // joins all fields and add to list
	                        result.add(joinArrays(pendingFieldLine, csvLineInArray));
	                        pendingFieldLine = new String[]{};
	                    } else {
	                        // if dun want to support multiline, only this line is required.
	                        result.add(csvLineInArray);
	                    }

	                }


	            }
	        }

	        return result;
	    }

	    public String[] parseLine(String line) throws Exception {
	        return parseLine(line, DEFAULT_SEPARATOR);
	    }
	    
	    public String[] parseLine(String line, char separator) throws Exception {
	        return parse(line, separator, DEFAULT_QUOTE_CHAR).toArray(String[]::new);
	    }
	    
	    private List<String> parse(String line, char separator, char quoteChar)
	            throws Exception {

	            List<String> result = new ArrayList<>();

	            boolean inQuotes = false;
	            boolean isFieldWithEmbeddedDoubleQuotes = false;

	            StringBuilder field = new StringBuilder();

	            for (char c : line.toCharArray()) {

	                if (c == DOUBLE_QUOTES) {               // handle embedded double quotes ""
	                    if (isFieldWithEmbeddedDoubleQuotes) {

	                        if (field.length() > 0) {       // handle for empty field like "",""
	                            field.append(DOUBLE_QUOTES);
	                            isFieldWithEmbeddedDoubleQuotes = false;
	                        }

	                    } else {
	                        isFieldWithEmbeddedDoubleQuotes = true;
	                    }
	                } else {
	                    isFieldWithEmbeddedDoubleQuotes = false;
	                }

	                if (isMultiLine) {                      // multiline, add pending from the previous field
	                    field.append(pendingField).append(NEW_LINE);
	                    pendingField = "";
	                    inQuotes = true;
	                    isMultiLine = false;
	                }

	                if (c == quoteChar) {
	                    inQuotes = !inQuotes;
	                } else {
	                    if (c == separator && !inQuotes) {  // if find separator and not in quotes, add field to the list
	                        result.add(field.toString());
	                        field.setLength(0);             // empty the field and ready for the next
	                    } else {
	                        field.append(c);                // else append the char into a field
	                    }
	                }

	            }

	            //line done, what to do next?
	            if (inQuotes) {
	                pendingField = field.toString();        // multiline
	                isMultiLine = true;
	            } else {
	                result.add(field.toString());           // this is the last field
	            }

	            return result;

	        }

	    
	    private String[] joinArrays(String[] array1, String[] array2) {
	        return Stream.concat(Arrays.stream(array1), Arrays.stream(array2))
	                .toArray(String[]::new);
	    }
	    
	    */
 	

}
