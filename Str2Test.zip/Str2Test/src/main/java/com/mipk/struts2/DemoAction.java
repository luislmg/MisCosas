package com.mipk.struts2;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

//import com.mipk.struts2.Product;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


import com.opensymphony.xwork2.ActionSupport;



public class DemoAction extends ActionSupport  {
	
	
	private static final long serialVersionUID = 1L;
	
	//create the logger for log4j2
	private static final Logger logger = LogManager.getLogger(DemoAction.class);
	

	private List<Product> products;

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public String execute() throws Exception {
		this.products = new ArrayList<Product>();
		this.products.add(new Product("p01", "name 1", "thumb1.gif", 2, 4));
		this.products.add(new Product("p02", "name 2", "thumb2.gif", 6, 3));
		this.products.add(new Product("p03", "name 3", "thumb3.gif", 8, 12));
		this.products.add(new Product("p04", "name 4", "thumb4.gif", 10, 19));
		this.products.add(new Product("p05", "name 5", "thumb5.gif", 11, 21));
		this.products.add(new Product("p06", "name 6", "thumb6.gif", 19, 22));
		this.products.add(new Product("p07 22", "name 7", "thumb7.gif", 18, 20));
		//LoadConfig();
		logger.error("-------- ALL OK DemoAction AHORA22 ------------ ");
		return SUCCESS;
	}
	
/*
 * No va
 */
			
	 public static void LoadConfig() {
	    	
		 String configFile = "conf/ConfigFile.properties";
	    	logger.debug("Hello from Log4j 2");
	    	logger.debug("load configFile: " + configFile);

	        try (InputStream input = new FileInputStream(configFile)) {

	            Properties prop = new Properties();

	            // load a properties file
	            prop.load(input);
	            
	         
	            
	            String dir = prop.getProperty("file.dir");
	            String fielName1 = prop.getProperty("file.name1");
	            String fileName2 = prop.getProperty("file.name2");
	            String fileCsvSep = prop.getProperty("fiel.csvSep");
	            
	          
	            
	            System.out.println(configFile);
	            System.out.println(dir);
	            System.out.println(fielName1);
	            System.out.println(fileName2);
	            System.out.println(fileCsvSep);
	            
	 
	        } catch (IOException ex) {
	        	logger.error(ex.getMessage());
	        	System.out.println("FileConfig NOT FOUND in : "+configFile);
	            //ex.printStackTrace();
	        }

	 }	

}
