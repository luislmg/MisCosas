package com.mipk.struts2.datat;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.mipk.struts2.DbOutils.DbConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class FetchDataDAO {
	
	private static final Logger logger = LogManager.getLogger(FetchDataDAO.class);
	
	 public FetchDataDAO() {
	        super();
	        // TODO Auto-generated constructor stub
	    }
	 
	 public void setProducts(List<FetchDataBean> FetchDataBeans) {
			this.FetchDataBeans = FetchDataBeans;
		}	
	 
	 public List<FetchDataBean> FetchDataBeans;
	 
	 public static List<FetchDataBean> getFetchData() throws Exception{
		 
		//Creamos una declaración (statement) de la conexión
		 Statement mStm = null;
		 ResultSet mRS = null;
		 List<FetchDataBean> FetchDataBeans = new ArrayList<FetchDataBean>();
	     
	     
	     java.sql.Connection conBD = null;
	     
			try {
				
				//call connection sql connection pool
		        conBD = DbConnection.getCon();
		        mStm = conBD.createStatement();
		        logger.debug("FetchDataDAO createStatemen OK");
				String query = "SELECT key1,name,salary,spend1,spend2,date_spend,date_close,Dept FROM dataT";

		       
		        //Ejecutamos una consulta SQL contra el statement anterior
		        //El resultado se guardará en el ResultSet
	       
	            mRS = mStm.executeQuery(query);
	            logger.debug("FetchDataDAO executeQuery OK");
	            
	            if (mRS != null) {
					while (mRS.next()) {
	
						FetchDataBeans.add(new FetchDataBean(mRS.getInt(1), mRS.getString(2), mRS.getInt(3), mRS.getInt(4), mRS.getInt(5), mRS.getString(6),mRS.getString(7),mRS.getInt(8)));

					}
				}
	            
	            mRS.close();
	        	mStm.close();
	        	conBD.close();
	            return FetchDataBeans;

			} catch (SQLException error) {
	        	logger.error(error.getMessage());
	        	throw new Exception(error.getMessage());  
	            
	        } catch (Exception err){
	        	logger.error(err.getMessage());
	        	throw new Exception(err.getMessage());
	            //System.out.println("Error : " + err.getMessage());
	        	
	        }
			finally {	
	 			if (mRS != null){
	 				try {
	 					mRS.close();
	 					} catch (Exception e) {
	 					}
	 			}
	 			if (mStm != null) {
	 				try {
	 					mStm.close();
	 					} catch (Exception e) {
	 					}
	 			}
	 				
	 			if (conBD != null) {
	 				try {
	 					conBD.close();
	 					} catch (Exception e) {
	 					}
	 			}		
	 		} 
	    	 
	    	 
		}

	

}
