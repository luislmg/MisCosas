package com.mipk.struts2;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

public class AuthenticationAction extends ActionSupport implements SessionAware {
	
	private static final Logger logger = LogManager.getLogger(AuthenticationAction.class);
	private static final long serialVersionUID = 1L;
	private Map<String, Object> sessionMap;
	private String userName;
	private String password;

	public String login() {
		String loggedUserName = null;

		// check if the userName is already stored in the session 
		if (sessionMap.containsKey("userName")) {
			loggedUserName = (String) sessionMap.get("userName");
		}
		
		logger.error("-- AuthenticationAction.login1 ------password-----> " + password + "<---name-->" + userName);
		
		if (loggedUserName != null && loggedUserName.equals("admin")) {
			return SUCCESS;	// return welcome page
		}
		
		// if no userName stored in the session, 
		// check the entered userName and password
		if (userName != null && userName.equals("luis1") 
				&& password != null && password.equals("luis1")) {
			
			// add userName to the session
			sessionMap.put("userName", userName);
			
			return SUCCESS;	// return welcome page
		}
		
		// in other cases, return login page
		return INPUT;
	}
	
	public String logout() {
		logger.error("-- AuthenticationAction.logout ------password-----> " + password + "<---name-->" + userName);

		// remove userName from the session
		if (sessionMap.containsKey("userName")) {
			sessionMap.remove("userName");
		}
		return SUCCESS;
	}

	@Override
	public void setSession(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
}