package com.mipk.struts2;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mipk.struts2.DbOutils.DbConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class TestDB  {
	
	
	private static final Logger logger = LogManager.getLogger(TestDB.class);
       
   
    public TestDB() {
        super();
        // TODO Auto-generated constructor stub
    }

	
    public List<Product> products;
    
    public static List<Product> getProducts() throws Exception{
    	
    	//Creamos una declaración (statement) de la conexión
		 Statement mStm = null;
		 ResultSet mRS = null;
		//List<Product> products = null;
	     List<Product> products = new ArrayList<Product>();
	     
	     java.sql.Connection conBD = null;
    	
    	 try {
    		//call connection sql connection pool
	        conBD = DbConnection.getCon();
	        mStm = conBD.createStatement();
	         logger.debug("DB createStatemen OK");
	       
	        //Ejecutamos una consulta SQL contra el statement anterior
	        //El resultado se guardará en el ResultSet
       
            mRS = mStm.executeQuery("Select code, iso_code, label from country_codes");
            logger.debug("DB executeQuery OK");
            
            int count = 0;
            while (mRS.next()) {
            	
        		products.add(new Product(mRS.getString(1), mRS.getString(2), mRS.getString(3), count, count*2));
        		
                //System.out.println("code: " + mRS.getString(1) 
                //+ " iso_code: " + mRS.getString(2)
                //+ " label: " + mRS.getString(3));
        		count++;
            }
           	mRS.close();
        	mStm.close();
        	conBD.close();      
            
            return products;
            
        } catch (SQLException error) {
        	logger.error(error.getMessage());
        	throw new Exception(error.getMessage());  
            //System.out.println("Error al ejecutar SQL en servidor MySQL/MariaDB: " + error.getMessage());
        } catch (Exception err){
        	logger.error(err.getMessage());
        	throw new Exception(err.getMessage());
            //System.out.println("Error : " + err.getMessage());
        	
        }
    	 
    	 finally {	
 			if (mRS != null){
 				try {
 					mRS.close();
 					} catch (Exception e) {
 					}
 			}
 			if (mStm != null) {
 				try {
 					mStm.close();
 					} catch (Exception e) {
 					}
 			}
 				
 			if (conBD != null) {
 				try {
 					conBD.close();
 					} catch (Exception e) {
 					}
 			}		
 		} 
    	 
    	
    	
		//return products;
	}
    
    public void setProducts(List<Product> products) {
		this.products = products;
	}	
    
    /*
     * Call initial context
     * and retrieve Datasoruce
     * get the sql connection from connection poll
     
    public static java.sql.Connection getCon () throws Exception {
		
		
		Connection con = null;
		
		//int ress = 0;
		try {
			//System.out.println ("Entro con2");
			InitialContext ctx = new InitialContext();
			Context env = (Context) ctx.lookup("java:comp/env");
			logger.debug("InitialContext OK");
			//System.out.println ("Entro con3");
			// nombre del recurso en el context.xml
			DataSource ds = (DataSource) env.lookup("jdbc/MariaDB");
			logger.debug("DataSource OK");
			//System.out.println ("Entro con4");

			
			con = ds.getConnection();
			logger.debug("getConnection OK");
			
			return con;
			
			
		} catch (Exception e) {
			logger.error(e.getMessage());
        	throw new Exception(e.getMessage());
			
		}
		
		

	}
*/
	

	

/*
	
	 private static void InitDBDriver() throws ClassNotFoundException {
	    	
	    	
	    	//la config esta en un properties que se carga con la clase ReadConfig
	    	
	    	
	    	logger.debug("InitDBDriver");
	    	String classForName = "com.mysql.cj.jdbc.Driver";
	        //Cargaremos el driver JDBC de acceso a MySQL/MariaDB
	        try {
	            
	            Class.forName(classForName);
	            logger.debug("Class.forname OK");
	            
	        } catch (ClassNotFoundException error) {
	        	logger.error(error.getMessage());
	            //System.out.println("Error al cargar el driver JDBC de MySQL: " + error.getMessage());
	        }
	 
	        
	    }
	    public static java.sql.Connection GetConn2  () {
	    	
	    	
	    	
	    	 //Realizamos la conexión con el servidor MySQL/MariaDB
	        //Con los datos de conexión: dirección, puerto, usuario y contraseña
	        //estos datos estan en un properties que se carga en ReadConfig.LoadConfig()
	        Connection conBD = null;
	        
	        try {
	        	InitDBDriver();
	        	//solo funciona si se utiliza el driver de MariaDb
	        	//conBD = DriverManager.getConnection(
	        	//	    "jdbc:mariadb://localhost:3306/database_name",
	        	//	    "user", "password"
	        	//	);
	        	// con el driver de mysql se utiliza esta cadena 
	            //conBD = DriverManager.getConnection(
	            //        "jdbc:mysql://localhost:3306/mydataB",
	            //        "luis2", "luismy");
	        	
	        	
	        	
	        			
	        			
	            conBD = DriverManager.getConnection(
	            		"jdbc:mysql://localhost:3306/mydataB","luis2", "luismy");
	            
	            logger.debug("DB Connection OK");
	            return conBD;
	           
	        } catch (Exception error) {
	        	logger.error(error.getMessage());
	            //System.out.println("Error al conectar con el servidor MySQL/MariaDB: " + error.getMessage());
	        }
	        return conBD;
	    	
	    }
	    
	    public static void CloseConn (java.sql.Connection conn){
	    	try {
	    		conn.close();
	    		logger.debug("Close Connection OK");
	    	 } catch (SQLException error) {
	         	logger.error(error.getMessage());
	             //System.out.println("Error al cerrar la conn MySQL/MariaDB: " + error.getMessage());
	    	 }
	    	}
*/

}
