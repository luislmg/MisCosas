package com.mipk.struts2;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;

public class DownloadFileAction extends ActionSupport implements SessionAware{

	private static final Logger logger = LogManager.getLogger(DownloadFileAction.class);
	private static final long serialVersionUID = 1L;
	private InputStream inputStream;
	private String fileName;
	private long contentLength;
	private String localDirectory;
	
	
	
	private Map<String, Object> sessionMap;
	
	@Override
	public void setSession(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}
	
	public void setlocalDirectory(String s) {
		  this.localDirectory = s;
	  }
	  public String getlocalDirectory() {
	    	return this.localDirectory;
	    }

	public String execute() throws Exception {
		
		try {
			
			String filetoDw = null;
			
			if (sessionMap.containsKey("DownloadFile")) {
				filetoDw = (String) sessionMap.get("DownloadFile");
			}
			
			logger.error("-- DownloadFileAction.0--> "  + filetoDw);
			//this value is in myapp.properties
		 	String UploadFiles = getText("UploadFiles");
			
		 	String filePath = ServletActionContext.getServletContext().getRealPath("/").concat(UploadFiles);  
		 	setlocalDirectory(filePath);
		 	
		 	logger.error("-- DownloadFileAction.12--> "  + filePath+"/"+filetoDw);
			
			File fileToDownload = new File(filePath+"/"+filetoDw);
	
			inputStream = new FileInputStream(fileToDownload);
			fileName = fileToDownload.getName();
			contentLength = fileToDownload.length();
			
			
			
			
			return SUCCESS;
		}
		catch (Exception es) {
			String s = es.toString();
		 	System.out.println(s);
    		logger.error(s);
    		this.setMsgErr(s);
    		return ERROR;
		}
	}
	
	public long getContentLength() {
		return contentLength;
	}

	public String getFileName() {
		return fileName;
	}

	public InputStream getInputStream() {
		return inputStream;
	}
	
	 /* Used to obtain a file listing for JSP display. */
	  public Set<String> getFileList() {
	    return Stream.of(new File(getlocalDirectory()).listFiles())
	      .filter(file -> !file.isDirectory())
	      .map(File::getName)
	      .collect(Collectors.toSet());
	  }
	  
	//setter and getter error msg
	    //and put error msg in errorDb.jsp
	    private String MsgErr;
	    public void setMsgErr(String msg) {
	    	this.MsgErr = msg;
	    }
	    public String getMsgErr() {
	    	return this.MsgErr;
	    }

		

}