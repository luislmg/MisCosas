package com.mipk.struts2.datat;

public class FetchDataBean {
	
	private int key1;
	private String name;
	private int salary;
	private int spend1;
	private int spend2;
	private String date_spend;
	private String date_close;
	private int Dept;
	
	public FetchDataBean(int kye1, String name, int salary, int spend1, int spend2, String date_spend,String date_close,int Dept) {
		this.key1 = kye1;
		this.name = name;
		this.salary = salary;
		this.spend1 = spend1;
		this.spend2 = spend2;
		this.date_spend = date_spend;
		this.date_close = date_close;
		this.Dept = Dept;
	}
	
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getKey1() {
		return key1;
	}
	public void setKey1(int key1) {
		this.key1 = key1;
	}
	public int getSpend1() {
		return spend1;
	}
	public void setSpend1(int spend1) {
		this.spend1 = spend1;
	}
	public int getSpend2() {
		return spend2;
	}
	public void setSpend2(int spend2) {
		this.spend2 = spend2;
	}
	public String getDate_spend() {
		return date_spend;
	}
	public void setDate_spend(String date_spend) {
		this.date_spend = date_spend;
	}
	public String getDate_close() {
		return date_close;
	}
	public void setDate_close(String date_close) {
		this.date_close = date_close;
	}
	public int getDept() {
		return Dept;
	}
	public void setDept(int dept) {
		Dept = dept;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
