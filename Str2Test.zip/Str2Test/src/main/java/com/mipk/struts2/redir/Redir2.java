package com.mipk.struts2.redir;


import com.opensymphony.xwork2.ActionSupport;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Redir2 extends ActionSupport {
	
	private static final long serialVersionUID = 1L;
	private static final Logger logger = LogManager.getLogger(Redir2.class);
	   private String name;
	  

	   public String execute() throws Exception {
		   
		logger.error("-------- Redir2.execute -name:" + name );

	    
	         return SUCCESS;
	    
	   }
	   
	   public String getName() {
	      return name;
	   }

	   public void setName(String name) {
	      this.name = name;
	   }
	   
	   

}


