package com.mipk.struts2.datat;


import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


import com.opensymphony.xwork2.ActionSupport;

public class FetchDataAction extends ActionSupport{

	private static final long serialVersionUID = 1L;
	private static final Logger logger = LogManager.getLogger(FetchDataAction.class);
	
	 private List<FetchDataBean> FetchDataBeans;
	    
	    public List<FetchDataBean> getFetchDataBeans() {
			return FetchDataBeans;
		}

		public void setFetchDataBeans(List<FetchDataBean> FetchDataBeans) {
			this.FetchDataBeans = FetchDataBeans;
		}
	
	public String execute() throws Exception {
		
		logger.debug("FetchDataAction execute");
		
		try {
			this.FetchDataBeans = FetchDataDAO.getFetchData();
			
			if (this.FetchDataBeans.size()==0) {
    			String s = "Error FetchDataBeans.size 0";
        		logger.error(s);
        		this.setMsgErr(s);
        		return ERROR;
    			
    		}
			
			return SUCCESS;
			
		}
		catch (Exception e) {
			logger.error(e.toString());
			setMsgErr(e.toString());
			return ERROR;
		}
		
		
		
		
	}
	
	//setter and getter error msg
    //and put error msg in errorDb.jsp
    private String MsgErr;
    public void setMsgErr(String msg) {
    	this.MsgErr = msg;
    }
    public String getMsgErr() {
    	return this.MsgErr;
    }
	

}
