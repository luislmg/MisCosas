package com.mipk.struts2;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

/*
 * this Interceptor work ok
 * 
 * inside the 
 * <package name = "helloworld" extends = "struts-default">
 * we put the interceptor declaration:
 *         <interceptor name = "myinterceptor"
 *             class = "com.mipk.struts2.MyInterceptor" />
 *       </interceptors>
 * in action we put the reference to the interceptor:
 *  <action name = "hello" class = "com.mipk.struts2.HelloWorldAction" method = "execute">
 *         <interceptor-ref name = "params"/>
 *         <interceptor-ref name = "myinterceptor" />
 * 
 */


public class MyInterceptor extends AbstractInterceptor {

	   private static final long serialVersionUID = 1L;

	public String intercept(ActionInvocation invocation)throws Exception {

	      /* let us do some pre-processing */
	      String output = "Pre-Processing"; 
	      System.out.println(output);

	      /* let us call action or next interceptor */
	      String result = invocation.invoke();

	      /* let us do some post-processing */
	      output = "Post-Processing"; 
	      System.out.println(output);

	      return result;
	   }
	}
