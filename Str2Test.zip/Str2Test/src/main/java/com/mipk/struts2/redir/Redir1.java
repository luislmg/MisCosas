package com.mipk.struts2.redir;


import com.opensymphony.xwork2.ActionSupport;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import org.apache.struts2.ServletActionContext;

public class Redir1 extends ActionSupport {
	
	private static final long serialVersionUID = 1L;
	private static final Logger logger = LogManager.getLogger(Redir1.class);
	   private String name;
	   private String typeRedir;

	   public String execute() throws Exception {
		   /*
		   String LocalName = ServletActionContext.getRequest().getLocalName();
		   String ContentType = ServletActionContext.getRequest().getContentType();
		   
		   String ServerName = ServletActionContext.getRequest().getServerName();
		   String QueryString = ServletActionContext.getRequest().getQueryString();
		   String RemoteAddr = ServletActionContext.getRequest().getRemoteAddr();
		   
		   logger.error("Redir1.execute LocalName:" + LocalName + "<---ContentType-->" + ContentType);
		   logger.error("Redir1.execute ServerName:" + ServerName + "<---QueryString-->" + QueryString);
		   logger.error("Redir1.execute RemoteAddr:" + RemoteAddr );
		   String ContextPath = ServletActionContext.getRequest().getContextPath();
		   logger.error("Redir1.execute ContextPath:" + ContextPath );
		   */
		   
		   
		   
		logger.error("-------- Redir1.execute -name:" + name + "<---typeRedir-->" + typeRedir);

	      if ("1".equals(typeRedir)) {
	         return SUCCESS;
	      } else if ("2".equals(typeRedir)) {
	         return ERROR;  
	      }
	      else
	      {
	    	  return NONE;
	      }
	   }
	   
	   public String getName() {
	      return name;
	   }

	   public void setName(String name) {
	      this.name = name;
	   }
	   
	   public String getTypeRedir() {
		      return typeRedir;
		   }

		   public void setTypeRedir(String typeRedir) {
		      this.typeRedir = typeRedir.toUpperCase();
		   }

}

