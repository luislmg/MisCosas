package com.mipk.struts2.reg;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.mipk.struts2.Product;
import com.mipk.struts2.Beans.Countries;
import com.mipk.struts2.FileOutils.LoadFile;

import com.opensymphony.xwork2.ActionSupport;

public class RegisterAction extends ActionSupport{
	
	private static final long serialVersionUID = 1L;
	private static final Logger logger = LogManager.getLogger(RegisterAction.class);
	private String email;
	private String userName;
	private String phone;
	private String adress;
	private String postOffice;
	private String location;
	private String country;
	
	private String selectedCountry;
	
	 private List<Countries> Countries;
	  
	 public List<Countries> Countries() {
			return Countries;
		}

		
	

	public String execute(){
		
		logger.error("-- RegisterAction1---email-->" + email + "---username:"+userName );
		
		LoadFile fl = new LoadFile();
		Hashtable<Integer, Object> milista1= fl.readCSV3();
		
		int ln = milista1.size();
		Enumeration<Integer> nmExt;
		
		int externalKey;
		nmExt = milista1.keys();
		System.out.println("-----------------------");
		
		milista1.forEach(
	            (k, v) -> System.out.println("Key : " + k + ", Value : " + v));
		
		System.out.println("-----------------------");

		logger.error("-- RegisterAction2---email-->" + phone + "---selectedCountry:"+selectedCountry );
		
		return "success";
	}
	
	public void validate() {
	      if (userName == null || userName.trim().equals("")) {
	         addFieldError("name","The name is required");
	      }
	      
	      if (email == null|| email.trim().equals("")) {
	         addFieldError("email","The email is required");
	      }
	      else {
	    	  if (!validateEmailAddress(email)) {
	    		  addFieldError("email"," . . . BAD email . . . . ");
	    	  }
	    		  
	      }
	      if (phone == null|| phone.trim().equals("")) {
		         addFieldError("phone","The phone number is required");
		      }
	      else {
	    	  if (!validateMobileNumber(phone)) {
	    		  addFieldError("phone"," . . . BAD phone number . . . . ");
	    	  }
	    	  
	      }
	      
	}
	
	//getter setters
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getSelectedCountry() {
		return selectedCountry;
	}

	public void setSelectedCountry(String s) {
		this.selectedCountry = s;
	}

	public String getCountry() {
		return this.selectedCountry;
	}
	public void setCountry() {
		
		this.country = this.selectedCountry;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPostOffice() {
		return postOffice;
	}
	public void setPostOffice(String postOffice) {
		this.postOffice = postOffice;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	private Pattern regexPattern;
    private Matcher regMatcher;

    public boolean validateEmailAddress(String emailAddress) {
    	String regex = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";
    	//String regex3 = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}";  
    	//String regex2 ="^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^-]+(?:\\.[a-zA-Z0-9_!#$%&'*+/=?`{|}~^-]+)*@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$";
        
    	regexPattern = Pattern.compile(regex);
    	regMatcher   = regexPattern.matcher(emailAddress);
        if(regMatcher.matches()) {
            return true;
        } else {
            return false;
        }
    }

    
    
    /* Following are valid phone number examples
     * "(123)4567890", "1234567890", "123-456-7890", "(123)456-7890",
     * Following are invalid phone numbers
     * "(1234567890)","123)4567890", "12345678901", "(1)234567890",
     * "(123)-4567890", "1", "12-3456-7890", "123-4567", "Hello world"};         
    */
    public boolean validateMobileNumber(String mobileNumber) {
    	//"^\\+[0-9]{2,3}+-[0-9]{10}$"
    	String regex = "(?:\\(\\d{3}\\)|\\d{3}[-]*)\\d{3}[-]*\\d{4}";
    	
        regexPattern = Pattern.compile(regex);
        regMatcher   = regexPattern.matcher(mobileNumber);
        if(regMatcher.matches()) {
            return true;
        } else {
            return false;
        }
    }
}
