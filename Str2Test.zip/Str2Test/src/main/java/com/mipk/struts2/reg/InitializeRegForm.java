package com.mipk.struts2.reg;

import java.io.BufferedReader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

import java.util.List;





import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.apache.struts2.ServletActionContext;


import com.opensymphony.xwork2.ActionSupport;


public class InitializeRegForm extends ActionSupport{
	
	private static final long serialVersionUID = 1L;
	private static final Logger logger = LogManager.getLogger(InitializeRegForm.class);
	private String noFiles = "!!!! NO FILES !!!!!";
	//data members
	private List<String> countriesList;
	
	//getter setters
		public List<String> getCountriesList() {
			return countriesList;
		}

		public void setCountriesList(List<String> countriesList) {
			this.countriesList = countriesList;
		}
		
		public String getDefaultSubject() {
			return "Spain";
		}
	
	public String execute(){
		
			return SUCCESS;	
				
	}
	
	public String initializeList(){
		
		countriesList = new ArrayList<String>();
		
		String filePath = ServletActionContext.getServletContext().getRealPath("/").concat("Resource").concat("/countries.csv");  

	 	 
	 	
	 	logger.error("-- InitializeRegForm.initializeList ---1--> "  + filePath);
	 	String FileToRead = filePath;
	 	String splitSep = ";";
	 	Path pathToFile = Paths.get(FileToRead );
	 	
	 	if (pathToFile.toFile().isFile()) {
		 	
	 		try (BufferedReader br = Files.newBufferedReader(pathToFile)) {
	    		String line = br.readLine();
	    		int count = 0;
	    		
	    		 
	    		while (line != null) {
	    			String[] attributes = line.split(splitSep);
	    			//int len = attributes.length;
	    			
	    			line = br.readLine();
	    			//Skip first line with titles
	    			if (count > 0) {
	    				
	    				//logger.error("Country Name:" + attributes[0]);
	    				//put the beans into the list
		    			
		    			countriesList.add(attributes[0]);
		    			
	    			}
	    			count++;
	    			
	    		}
	    		logger.error("nitializeRegForm.initializeList 2" + filePath);
	    		
	    		
	    	} 
	    	catch (IOException ioe) {
	    		
	    		logger.error("Error File");
		    	
	    	}
	 	}
	 	else
	 	{
	 		logger.error("File Not found");
	 		countriesList.add(noFiles);
	    	
	 	}
	 	
		return NONE;
	}



}
